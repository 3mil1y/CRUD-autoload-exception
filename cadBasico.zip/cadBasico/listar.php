<?php

require 'siteConfig.php';
$colaboradores = listarColaboradores();
use Classes\Endereco;
use Classes\Colaborador;

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Colaboradores</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Colaboradores</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Estado Civil</th>
                    <th>CPF</th>
                    <th>Email</th>
                    <th>Telefone</th>
                    <th>Endereço</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    //verifica se o vet está vazio
                    if (empty($colaboradores)){
                        echo
                        '<tr>
                            <td colspan="7" class="text-center">Nenhum colaborador encontrado.</td>
                        </tr>';
                    }

                else{
                    foreach ($colaboradores as $colab){
                        echo
                        "<tr>
                            <td>" . $colab->getNome() . "</td>
                            <td>" . $colab->getEstadoCivil() . "</td>
                            <td>" . $colab->getCpf() . "</td>
                            <td>" . $colab->getEmail() . "</td>
                            <td>" . $colab->getTelefone() . "</td>
                            <td>" . $colab->getEndereco()->toString() . "</td>
                        </tr>";
                    }
                }
                ?>
            </tbody>
        </table>

        <a href="criar.php" class="btn btn-primary">Cadastrar Novo Colaborador</a>
    </div>
</body>
</html>