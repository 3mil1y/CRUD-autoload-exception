<?php

namespace Classes;

class Endereco{
    private $rua;
    private $cidade;
    private $estado;
    private $cep;

    public function __construct($rua, $cidade, $estado, $cep) {
        $this->rua = $rua;
        $this->cidade = $cidade;
        $this->estado = $estado;
        $this->cep = $cep;
    }

    // Getters
    public function getRua() {
        return $this->rua;
    }

    public function getCidade() {
        return $this->cidade;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getCep() {
        return $this->cep;
    }

    // Setters
    public function setRua($rua) {
        $this->rua = $rua;
    }

    public function setCidade($cidade) {
        $this->cidade = $cidade;
    }

    public function setEstado($estado) {
        $this->estado = $estado;
    }

    public function setCep($cep) {
        $this->cep = $cep;
    }

    public function toString() {
        return "{$this->rua}, {$this->cidade} - {$this->estado}, {$this->cep}";
    }
}


?>