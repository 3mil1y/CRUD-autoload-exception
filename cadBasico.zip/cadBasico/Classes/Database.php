<?php

namespace Classes;

use mysqli;
use Exception;

class Database{

    private $host;
    private $username;
    private $password;
    private $database;
    private $connection;

    public function __construct($host, $username, $password, $database)
    {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;

        $this->connect();
    }

    private function connect()
    {
        $this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);

        if ($this->connection->connect_error) {
            throw new Exception("Connection failed: " . $this->connection->connect_error);
        }
    }

    public function query($sql)
    {
        $result = $this->connection->query($sql);
        
        if (!$result) {
            throw new Exception("Query failed: " . $this->connection->error);
        }
        
        return $result;
    }

    public function close()
    {
        $this->connection->close();
    }

    public function getId()
    {
        return $this->connection->insert_id;
    }
}
?>