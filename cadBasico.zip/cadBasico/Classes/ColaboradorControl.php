<?php

namespace Classes;;

use Classes\Database;
use Classes\Colaborador;
use Exception;

class ColaboradorControl {
    private $conexao;

    public function __construct(Database $baseDados) {
        $this->conexao = $baseDados;
    }

    public function listar() {
        $sql = "SELECT cpf FROM colaboradores";
        $result = $this->conexao->query($sql);

        $colaboradores = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $colaboradores[] = $this->buscarPorCpf($row["cpf"]);
            }
        }

        return $colaboradores;
    }

    public function atualizar($colaborador) {
        $sql = "UPDATE colaboradores SET nome = '".$colaborador->getNome()."', estadoCivil = '".$colaborador->getEstadoCivil()."', email = '".$colaborador->getEmail()."', telefone = '".$colaborador->getTelefone()."' WHERE cpf = '".$colaborador->getCpf()."'";
        
        return $this->conexao->query($sql);
    }

    public function deletar($cpf) {
        $sql = "DELETE FROM colaboradores WHERE cpf = '".$cpf."'";
        return $this->conexao->query($sql);
    }

    public function cadastrar($colaborador, $idEndereco) {
        if ($this->buscarPorCpf($colaborador->getCpf())!=null){
            throw new Exception("Cpf já cadastrado!");
        }

      $sql = "INSERT INTO colaboradores (nome, estadoCivil, cpf, email, telefone, idEndereco) VALUES ('".$colaborador->getNome()."', '".$colaborador->getEstadoCivil()."', '".$colaborador->getCpf()."', '".$colaborador->getEmail()."', '".$colaborador->getTelefone()."', '".$idEndereco."')";

        return $this->conexao->query($sql);
    }

    public function buscarPorCpf($cpf) {
        $sql = "SELECT * FROM colaboradores WHERE cpf = '".$cpf."'";
        $result = $this->conexao->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $colab = new Colaborador($row["nome"], $row["estadoCivil"], $row["cpf"], $row["email"], $row["telefone"]);
            $colab->setIdEndereco($row["idEndereco"]);
            return $colab;
        } else {
            return null;
        }
    }
}
