<?php

namespace Classes;
use Classes\Database;
use Classes\Endereco;

class EnderecoControl {
    private $conexao;

    public function __construct(Database $baseDados) {
        //obj da classe Database
        $this->conexao = $baseDados;
    }

    //retorna vet de enderecos
    public function listar() {
        $sql = "SELECT * FROM endereco";
        $result = $this->conexao->query($sql);
        
        $enderecos = [];
        
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $enderecos[] = new Endereco($row["rua"], $row["cidade"], $row["estado"], $row["CEP"]);
            }
        }
        
        return $enderecos;
    }

    //busca endereco por id para associação ao colaborador
    public function buscarPorId($id) {
        $sql = "SELECT * FROM endereco WHERE idEndereco = $id";
        $result = $this->conexao->query($sql);
        
        if ($result != false && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return new Endereco($row["rua"], $row["cidade"], $row["estado"], $row["CEP"]);
        } else {
            return null;
        }
    }

    //cadastra endereco e retorna seu id
    public function cadastrar($endereco) {
        $sql = "INSERT INTO endereco (rua, cidade, estado, CEP) VALUES ('" . $endereco->getRua() . "', '" . $endereco->getCidade() . "', '" . $endereco->getEstado() . "', '" . $endereco->getCep() . "')";
        
        $this->conexao->query($sql);

        return $this->conexao->getId();
    }

    public function atualizar($endereco, $id) {
        $sql = "UPDATE endereco SET rua='" . $endereco->getRua() . "', cidade='" . $endereco->getCidade() . "', estado='" . $endereco->getEstado() . "', CEP='" . $endereco->getCep() . "' WHERE idEndereco='$id'";
        
        return $this->conexao->query($sql);
    }

    public function deletar($id) {
        $sql = "DELETE FROM endereco WHERE idEndereco='$id'";
        return $this->conexao->query($sql);
    }
}