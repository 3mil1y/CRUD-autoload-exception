<?php

namespace Classes;

use Classes\endereco;

class Colaborador {
    private $nome;
    private $estadoCivil;
    private $cpf;
    private $email;
    private $telefone;
    private $endereco;
    private $idEndereco;

    public function __construct($nome, $estadoCivil, $cpf, $email, $telefone, Endereco $endereco = null, $idEndereco = -1) {
        $this->nome = $nome;
        $this->estadoCivil = $estadoCivil;
        $this->cpf = $cpf;
        $this->email = $email;
        $this->telefone = $telefone;
        $this->endereco = $endereco;
        $this->idEndereco = $idEndereco;
    }

    // Getters
    public function getNome() {
        return $this->nome;
    }

    public function getEstadoCivil() {
        return $this->estadoCivil;
    }

    public function getCpf() {
        return $this->cpf;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getTelefone() {
        return $this->telefone;
    }

    public function getEndereco() {
        return $this->endereco;
    }

    public function getIdEndereco() {
        return $this->idEndereco;
    }

    // Setters
    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function setEstadoCivil($estadoCivil) {
        $this->estadoCivil = $estadoCivil;
    }

    public function setCpf($cpf) {
        $this->cpf = $cpf;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function setTelefone($telefone) {
        $this->telefone = $telefone;
    }

    public function setEndereco(Endereco $endereco) {
        $this->endereco = $endereco;
    }

    public function setIdEndereco($idEndereco) {
        $this->idEndereco = $idEndereco;
    }

    public function toString() {
        return "Nome: {$this->nome}, Estado Civil: {$this->estadoCivil}, CPF: {$this->cpf}, Email: {$this->email}, Telefone: {$this->telefone}, Endereço: {".$this->endereco->toString()."}";
    }
}


?>