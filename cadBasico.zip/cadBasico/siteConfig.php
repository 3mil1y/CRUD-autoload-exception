<?php

spl_autoload_register(function ($nomeClasse) {
   
    if (class_exists($nomeClasse, false)) {
        return;
    }

    $directory = __DIR__ . '/';
    $caminho = $directory.str_replace('\\', DIRECTORY_SEPARATOR, $nomeClasse).'.php';

    if (file_exists($caminho)) {
        include $caminho;
    } else {
        throw new Exception("A classe: ".$nomeClasse." não foi encontrada.");
    }
});

use Classes\Colaborador;
use Classes\Database;
use Classes\Endereco;
use Classes\ColaboradorControl;
use Classes\EnderecoControl;

$bdUsuarios = new Database("localhost", "root", "", "bd_usuarios");
$colabControl = new ColaboradorControl($bdUsuarios);
$endeControl = new EnderecoControl($bdUsuarios);

function cadastrarColaborador(Colaborador $colaborador){
    global $colabControl, $endeControl;



    $idEndereco = $endeControl->cadastrar($colaborador->getEndereco());
    try {
    $colabControl->cadastrar($colaborador,$idEndereco);
    } catch (Exception $e){
        $endeControl->deletar($idEndereco);
        echo $e->getMessage();
    }

}

function listarColaboradores(){
    global $colabControl, $endeControl;

    $vetColab = $colabControl->listar();

    foreach($vetColab as $colab){
        $idEndereco = $colab->getIdEndereco();
        $colab->setEndereco($endeControl->buscarPorId($idEndereco));
    }

    return $vetColab;
}

function excluirUsuario($cpf){
    global $colabControl, $endeControl;

    $colabExclusao = $colabControl->buscarPorCpf($cpf);

    if ($colabExclusao) {
        $colabControl->deletar($cpf);
        $endeControl->deletar($colabExclusao->getIdEndereco());
    } else {
        throw new Exception("Colaborador não encontrado.");
    }
}

function atualizarColaboraor($colaborador){
    global $colabControl, $endeControl;

    $endeControl->atualizar($colaborador->getEndereco(),$colaborador->getIdEndereco);
    $colabControl->atualizar($colaborador);
}

function buscaColaborador($cpf){
    global $colabControl, $endeControl;

    $colab = $colabControl->buscarPorCpf($cpf);
    $idEndereco = $colab->getIdEndereco();
    $colab->setEndereco($endeControl->buscarPorId($idEndereco));

    return $colab;
}