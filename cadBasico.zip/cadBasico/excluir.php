<?php

require_once 'siteConfig.php';

if (isset($_POST['delete'])) {
    $cpf = $_POST['cpf'];
    excluirUsuario($cpf);
}

$colaboradores = listarColaboradores();

echo    '<!DOCTYPE html>
        <html lang="pt-BR">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Listar Colaboradores</title>
            <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
                <div class="container mt-5">
                <h1 class="text-center">Colaboradores</h1>
                <table class="table table-striped table-bordered mt-4">
                    <thead class="thead-dark">
                        <tr>
                            <th>Nome</th>
                            <th>CPF</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>';

foreach ($colaboradores as $colaborador) {
    echo '<tr>
            <td>' . $colaborador->getNome() . '</td>
            <td>' . $colaborador->getCpf() . '</td>
            <td>
                <form action="" method="post" style="display:inline;">
                    <input type="hidden" name="cpf" value="' . $colaborador->getCpf() . '">
                    <button type="submit" name="delete" class="btn btn-danger btn-sm">Excluir</button>
                </form>
            </td>
          </tr>';
}

echo '      </tbody>
        </table>
      </div>';
?>