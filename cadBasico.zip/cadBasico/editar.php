<?php

require_once 'siteConfig.php';
$colaboradores = listarColaboradores();
use Classes\Endereco;
use Classes\Colaborador;

echo '<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Colaborador</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Editar Colaborador</h2>
        <form action="" method="post" class="mt-4">
            <div class="form-group">
                <label for="colaborador">Selecione um Colaborador:</label>
                <select id="colaborador" name="cpf" class="form-control" required onchange="this.form.submit()">
                    <option value="">Escolha um colaborador</option>';
                    foreach ($colaboradores as $colaborador) {
                        echo '<option value="' . $colaborador->getCpf() . '">' . $colaborador->getNome() . ' - ' . $colaborador->getCpf() . '</option>';
                    }
echo '          </select>
            </div>
        </form>';

if (isset($_POST['cpf'])) {
    $cpfSelecionado = $_POST['cpf'];
    $colabEdicao = buscaColaborador($cpfSelecionado);

    if ($colabEdicao) {
        echo '<form action="editar.php" method="post" class="mt-4">
                <h5>Colaborador</h5>
                <input type="hidden" name="cpf" value="' . $colabEdicao->getCpf() . '">
                <input type="hidden" name="idEndereco" value="' . $colabEdicao->getIdEndereco() . '">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome:</label>
                    <input type="text" class="form-control" required id="nome" name="nome" value="' . $colabEdicao->getNome() . '" placeholder="Informe o nome">
                </div>
                <div class="mb-3">
                    <label for="estadoCivil" class="form-label">Estado Civil:</label>
                    <input type="text" class="form-control" required id="estadoCivil" name="estadoCivil" value="' . $colabEdicao->getEstadoCivil() . '" placeholder="Informe o estado civil">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">E-mail:</label>
                    <input type="email" class="form-control" required id="email" name="email" value="' . $colabEdicao->getEmail() . '" placeholder="Insira o seu e-mail">
                </div>
                <div class="mb-3">
                    <label for="telefone" class="form-label">Telefone:</label>
                    <input type="text" class="form-control" required id="telefone" name="telefone" value="' . $colabEdicao->getTelefone() . '" placeholder="Insira o telefone">
                </div>
                <h5>Endereço</h5>
                <div class="mb-3">
                    <label for="rua" class="form-label">Rua:</label>
                    <input type="text" class="form-control" required id="rua" name="rua" value="' . $colabEdicao->getEndereco()->getRua() . '" placeholder="Informe a rua">
                </div>
                <div class="mb-3">
                    <label for="cidade" class="form-label">Cidade:</label>
                    <input type="text" class="form-control" required id="cidade" name="cidade" value="' . $colabEdicao->getEndereco()->getCidade() . '" placeholder="Informe a cidade">
                </div>
                <div class="mb-3">
                    <label for="estado" class="form-label">Estado:</label>
                    <input type="text" class="form-control" required id="estado" name="estado" value="' . $colabEdicao->getEndereco()->getEstado() . '" placeholder="Informe o estado">
                </div>
                <div class="mb-3">
                    <label for="cep" class="form-label">CEP:</label>
                    <input type="text" class="form-control" required id="cep" name="cep" value="' . $colabEdicao->getEndereco()->getCep() . '" placeholder="Informe o CEP">
                </div>
                <button type="submit" name="update" class="btn btn-primary">Atualizar</button>
            </form>';
    }
}

echo '</div>
</body>
</html>';

if (isset($_POST['update'])) {
    $nome = $_POST['nome'];
    $estadoCivil = $_POST['estadoCivil'];
    $cpf = $_POST['cpf'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $rua = $_POST['rua'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $cep = $_POST['cep'];

    $idEndereco = $_POST['idEndereco'];

    $endereco = new Endereco($rua, $cidade, $estado, $cep);
    $colaborador = new Colaborador($nome, $estadoCivil, $cpf, $email, $telefone, $endereco);
    $colaborador->setIdEndereco($idEndereco);

    atualizarColaboraor($colaborador);

    header("Location: index.php");
}

?>