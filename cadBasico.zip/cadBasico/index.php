<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Principal</title>
    <!-- tela feita utilizando booystrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center">Gerenciamento de Colaboradores</h1>
    <div class="text-center mt-4">
        <a href="criar.php" class="btn btn-primary mx-2">Cadastrar</a>
        <a href="listar.php" class="btn btn-success mx-2">Listar</a>
        <a href="editar.php" class="btn btn-warning mx-2">Editar</a>
        <a href="excluir.php" class="btn btn-danger mx-2">Excluir</a>
    </div>
</div>


</body>
</html>