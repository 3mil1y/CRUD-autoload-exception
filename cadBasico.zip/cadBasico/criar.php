<?php

require_once 'siteConfig.php';

echo '<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Colaborador</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Cadastrar Colaborador</h2>
        <form action="criar.php" method="post" class="mt-4">
            <h5>Colaborador</h5>
            <div class="mb-3">
                <label for="nome" class="form-label">Nome:</label>
                <input type="text" class="form-control" required id="nome" name="nome" placeholder="Informe o nome">
            </div>
            <div class="mb-3">
                <label for="estadoCivil" class="form-label">Estado Civil:</label>
                <input type="text" class="form-control" required id="estadoCivil" name="estadoCivil" placeholder="Informe o estado civil">
            </div>
            <div class="mb-3">
                <label for="cpf" class="form-label">CPF:</label>
                <input type="text" class="form-control" required id="cpf" name="cpf" placeholder="Insira o CPF">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail:</label>
                <input type="email" class="form-control" required id="email" name="email" placeholder="Insira o seu e-mail">
            </div>
            <div class="mb-3">
                <label for="telefone" class="form-label">Telefone:</label>
                <input type="text" class="form-control" required id="telefone" name="telefone" placeholder="Insira o telefone">
            </div>
            <h5>Endereço</h5>
            <div class="mb-3">
                <label for="rua" class="form-label">Rua:</label>
                <input type="text" class="form-control" required id="rua" name="rua" placeholder="Informe a rua">
            </div>
            <div class="mb-3">
                <label for="cidade" class="form-label">Cidade:</label>
                <input type="text" class="form-control" required id="cidade" name="cidade" placeholder="Informe a cidade">
            </div>
            <div class="mb-3">
                <label for="estado" class="form-label">Estado:</label>
                <input type="text" class="form-control" required id="estado" name="estado" placeholder="Informe o estado">
            </div>
            <div class="mb-3">
                <label for="cep" class="form-label">CEP:</label>
                <input type="text" class="form-control" required id="cep" name="cep" placeholder="Informe o CEP">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>
    </body>
    <br>';

use Classes\Endereco;
use Classes\Colaborador;

if (isset($_POST['submit'])){


$nome = $_POST['nome'];
$estadoCivil = $_POST['estadoCivil'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$rua = $_POST['rua'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$cep = $_POST['cep'];

// Cria os objetos
$endereco = new Endereco($rua, $cidade, $estado, $cep);
$colaborador = new Colaborador($nome, $estadoCivil, $cpf, $email, $telefone, $endereco);

cadastrarColaborador($colaborador);
}

